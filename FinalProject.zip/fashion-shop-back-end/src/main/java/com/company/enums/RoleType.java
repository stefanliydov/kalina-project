package com.company.enums;

public enum RoleType {
    ADMIN,
    CUSTOMER,
    BUSINESS_CUSTOMER
}