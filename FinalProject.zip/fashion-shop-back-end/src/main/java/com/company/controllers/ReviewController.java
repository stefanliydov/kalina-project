package com.company.controllers;

import com.company.data.dtos.ReviewDetailsModel;
import com.company.services.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "reviews")
public class ReviewController {

    private final ReviewService reviewService;

    @Autowired
    public ReviewController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }

    @RequestMapping(method = RequestMethod.GET,path = "/getAllReviews/{id}")
    public ResponseEntity<List<ReviewDetailsModel>> getAllAwardReviews(@PathVariable Long id){
        List<ReviewDetailsModel> reviews = this.reviewService.getAllReviewsByAwardId(id);
        return new ResponseEntity<>(reviews, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.POST, path = "/addItemReview/{id}")
    public ResponseEntity<HttpStatus> addAwardReview(@RequestBody ReviewDetailsModel review, @PathVariable Long id){
        this.reviewService.addReview(review, id);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }
}