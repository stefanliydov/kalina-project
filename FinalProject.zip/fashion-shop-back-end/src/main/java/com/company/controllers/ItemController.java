package com.company.controllers;

import com.company.data.dtos.ItemDto;
import com.company.data.dtos.ItemModel;
import com.company.data.entities.Item;
import com.company.services.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "item")
public class ItemController {

    @Autowired
    private ItemService itemService;

    @RequestMapping(method = RequestMethod.GET, path = "/all-items")
    public ResponseEntity<List<ItemModel>> getItemList() {
        return new ResponseEntity<>(itemService.getAllItems(), HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET, path = "/{id}")
    public ResponseEntity<ItemDto> getItemById(@PathVariable final Long id) {
        return new ResponseEntity<>(this.itemService.getItemById(id), HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET, path = "/category/{category}")
    public ResponseEntity<List<ItemDto>> getItemsByCategory(@PathVariable final String category) {
        return new ResponseEntity<>(itemService.getItemsByCategory(category), HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<ItemDto> addItem(@RequestBody final ItemDto item) {
        return new ResponseEntity<>(itemService.createItem(item), HttpStatus.CREATED);
    }

    @RequestMapping(method = RequestMethod.DELETE, path = "/delete/{id}")
    public ResponseEntity deleteItem(@PathVariable final Long id) {
        itemService.deleteItem(id);
        return new ResponseEntity(HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.PUT, path = "/edit/{id}")
    public ResponseEntity editItem(@PathVariable final Long id, @RequestBody final ItemDto editedItem) {
        itemService.editItem(id, editedItem);
        return new ResponseEntity(HttpStatus.OK);
    }
}
