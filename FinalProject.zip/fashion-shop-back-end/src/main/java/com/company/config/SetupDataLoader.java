package com.company.config;

import com.company.data.dtos.RegisterUserModel;
import com.company.data.entities.Role;
import com.company.data.entities.User;
import com.company.enums.RoleType;
import com.company.errors.exceptions.RoleNotFoundException;
import com.company.repositories.RoleRepository;
import com.company.services.RoleService;
import com.company.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;

@Component
public class SetupDataLoader implements
        ApplicationListener<ContextRefreshedEvent> {

    boolean alreadySetup = false;

    @Autowired
    private RoleService roleService;
    @Autowired
    private UserService userService;


    @Override
    @Transactional
    public void onApplicationEvent(ContextRefreshedEvent event) {
        if (alreadySetup)
            return;
        createRoleIfNotFound(RoleType.ADMIN);
        createRoleIfNotFound(RoleType.CUSTOMER);
        createRoleIfNotFound(RoleType.BUSINESS_CUSTOMER);
        createUser("admin","password", "admin@gmail.com", new RoleType[]{RoleType.ADMIN, RoleType.BUSINESS_CUSTOMER, RoleType.CUSTOMER});
        createUser("business_customer","password", "business_customer@gmail.com", new RoleType[]{RoleType.BUSINESS_CUSTOMER, RoleType.CUSTOMER});
        createUser("customer","password", "customer@gmail.com", new RoleType[]{RoleType.CUSTOMER});
        alreadySetup = true;
    }


    @Transactional
    private Role createRoleIfNotFound(
            RoleType roleType) {
        Role role;
        try {
            role = roleService.findByRoleType(roleType.name());
        } catch(RoleNotFoundException e) {
                role = new Role();
                role.setRoleType(roleType);
                roleService.createRole(role);
        }
        return role;
    }

    private void createUser(String username, String password, String email, RoleType[] roleType) {
        RegisterUserModel user = new RegisterUserModel();
        try {
            this.userService.getUserByUsername(username);
        } catch (UsernameNotFoundException ex) {
            user.setUsername(username);
            user.setPassword(password);
            user.setEmail(email);
            this.userService.registerUser(roleType, user);
        }
    }
}
