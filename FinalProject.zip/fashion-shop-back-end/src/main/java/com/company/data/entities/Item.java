package com.company.data.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "items")
public class Item extends BaseEntity {
   private String title;
   private String description;
   private double price;
   private String image;
   private String category;
   private Double rating;


   @OneToMany(mappedBy = "item", cascade = CascadeType.ALL)
   @ToString.Exclude
   private List<Review> reviews;
}
