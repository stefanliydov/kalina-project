package com.company.data.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ItemDto {
    private Long id;
    private String title;
    private String description;
    private double price;
    private String image;
    private String category;
    private List<ReviewDetailsModel> reviews;
}
