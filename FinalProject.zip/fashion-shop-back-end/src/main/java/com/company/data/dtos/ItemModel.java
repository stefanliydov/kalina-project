package com.company.data.dtos;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ItemModel {
    private Long id;
    private String title;
    private String description;
    private double price;
    private String image;
    private String category;
    private List<ReviewDetailsModel> reviews;
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date createDate16114107;
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date modifyDate16114107;
}
