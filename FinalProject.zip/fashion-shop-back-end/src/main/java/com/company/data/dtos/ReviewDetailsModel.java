package com.company.data.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReviewDetailsModel {

    private String title;
    private String comment;
    private Double rating;
    private String userUsername;
}

