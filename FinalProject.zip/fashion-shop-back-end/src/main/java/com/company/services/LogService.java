package com.company.services;

import com.company.data.dtos.LogDto;
import com.company.data.entities.Log;
import com.company.repositories.LogRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class LogService {

    @Autowired
    private LogRepository logRepository;
    @Autowired
    private ModelMapper modelMapper;


    public void logAction(Log log){
        this.logRepository.save(log);
    }

    public List<LogDto> getLogData() {
    return this.logRepository.findAll()
            .stream()
            .map(x -> this.modelMapper.map(x, LogDto.class))
            .collect(Collectors.toList());
    }
}
