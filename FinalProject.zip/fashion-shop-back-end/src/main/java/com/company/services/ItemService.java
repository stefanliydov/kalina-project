package com.company.services;

import com.company.data.dtos.ItemDto;
import com.company.data.dtos.ItemModel;
import com.company.data.dtos.ReviewDetailsModel;
import com.company.data.entities.Item;
import com.company.repositories.ItemRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ItemService {

    @Autowired
    private ItemRepository itemRepository;
    @Autowired
    private ModelMapper modelMapper;

    public List<ItemModel> getAllItems() {
        return this.itemRepository.findAll().stream()
                .map(r -> this.modelMapper.map(r, ItemModel.class))
                .collect(Collectors.toList());

    }

    public ItemDto getItemById(Long id) {
        final Item item = this.itemRepository.findById(id).orElseThrow(() -> new RuntimeException("Item not found"));
        return this.modelMapper.map(item, ItemDto.class);
    }

    public List<ItemDto> getItemsByCategory(String category) {
        return this.itemRepository.findAllByCategory(category).stream().map(r -> this.modelMapper.map(r, ItemDto.class))
                .collect(Collectors.toList());
    }

    public ItemDto createItem(ItemDto item) {
        final Item itemEntity = this.modelMapper.map(item, Item.class);
        this.itemRepository.save(itemEntity);
        return item;
    }

    public void deleteItem(Long id) {
        Item item = this.itemRepository.findById(id).orElseThrow(() -> new RuntimeException("Item for deletion not found."));
        this.itemRepository.deleteById(id);
    }

    public void editItem(Long id, ItemDto editedItem) {
        System.out.println("EDITINGGGG....");
        final Item item = this.itemRepository.findById(id).orElseThrow(() -> new RuntimeException("Item for editing not found."));
        editExistingItem(item, editedItem);
        System.out.println(item);
        this.itemRepository.saveAndFlush(item);

    }

    private void editExistingItem(Item item, ItemDto editedItem) {
        item.setTitle(editedItem.getTitle());
        item.setPrice(editedItem.getPrice());
        item.setImage(editedItem.getImage());
        item.setDescription(editedItem.getDescription());
        item.setCategory(editedItem.getCategory());
    }
}
