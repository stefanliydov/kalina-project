package com.company.services;

import com.company.constants.Errors;
import com.company.data.dtos.ReviewDetailsModel;
import com.company.data.entities.Item;
import com.company.data.entities.Review;
import com.company.data.entities.User;
import com.company.errors.exceptions.ItemNotFoundException;
import com.company.repositories.ItemRepository;
import com.company.repositories.ReviewRepository;
import com.company.repositories.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReviewService {
    private final ReviewRepository reviewRepository;
    private final UserRepository userRepository;
    private final ItemRepository itemRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public ReviewService(ReviewRepository reviewRepository, UserRepository userRepository, ItemRepository itemRepository, ModelMapper modelMapper) {
        this.reviewRepository = reviewRepository;
        this.userRepository = userRepository;
        this.itemRepository = itemRepository;
        this.modelMapper = modelMapper;
    }

    public void addReview(ReviewDetailsModel review, Long itemId) {
        validateReviewRating(review);
        final User user = this.userRepository.findByUsername(review.getUserUsername()).orElseThrow(() -> new UsernameNotFoundException(Errors.USERNAME_NOT_FOUND));
        final Item item = this.itemRepository.findById(itemId).orElseThrow(() -> new ItemNotFoundException(Errors.ITEM_NOT_FOUND));
        Review reviewEntity = modelMapper.map(review, Review.class);
        reviewEntity.setItem(item);
        reviewEntity.setUser(user);
        this.reviewRepository.saveAndFlush(reviewEntity);
        this.updateAwardRating(item);
    }

    private void validateReviewRating(ReviewDetailsModel review) {
        if(review.getRating()> 5.00){
            review.setRating(5.00);
        }else if(review.getRating() <0.00){
            review.setRating(0.00);
        }
    }



    public List<ReviewDetailsModel> getAllReviewsByAwardId(Long id) {
        return this.reviewRepository.findAllByItemId(id)
                .stream()
                .map(r -> this.modelMapper.map(r, ReviewDetailsModel.class))
                .collect(Collectors.toList());
    }


    private void updateAwardRating(final Item item) {
        final List<Review> reviews = this.reviewRepository.findAllByItemId(item.getId());
        Double averageRating = reviews.stream().mapToDouble(Review::getRating).average().orElse(0);
        item.setRating(averageRating);
        this.itemRepository.save(item);
    }
}
