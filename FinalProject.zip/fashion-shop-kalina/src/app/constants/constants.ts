export enum AuthKeywords {
    USERNAME = 'username',
    AUTH_TOKEN = 'auth_token',
    ROLES = 'roles',
    JWT = 'jwt'
}

export enum Roles {
    ADMIN = 'ADMIN',
    CUSTOMER = 'CUSTOMER',
    BUSINESS_CUSTOMER = 'BUSINESS_CUSTOMER'
}


export enum APIUrl {
    BACK_END_URL = 'http://localhost:8080'
}

export const InterceptorSkipHeader = 'X-Skip-Interceptor';
