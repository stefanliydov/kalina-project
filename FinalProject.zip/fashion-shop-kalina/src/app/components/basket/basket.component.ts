import { Component, OnInit } from '@angular/core';
import { Item } from 'src/app/models/Item';
import { ItemService } from 'src/app/services/item/item.service';
import { StorageService } from 'src/app/services/storage/storage.service';

@Component({
  selector: 'app-basket',
  templateUrl: './basket.component.html',
  styleUrls: ['./basket.component.scss']
})
export class BasketComponent implements OnInit {

  constructor(private storage: StorageService, private itemService: ItemService) { }
  products: Item[]
  total: number;
  quantity: number;
  productsIdQuantity: Map<String, String>
  ngOnInit(): void {
    this.products = [];
    this.total = 0.00;
    this.quantity = 1;

    this.productsIdQuantity = this.storage.getAllItems();

    this.productsIdQuantity.forEach((value: string, key: string) => {
      if (key === 'username' || key === 'roles') {
        return;
      }
      this.itemService.getItemById(key).subscribe(
        (item: Item) => {
          this.products.push(item);
          this.total = this.total + Number(item.price);
        });
    });
  }


  removeItem(id: string) {
    this.products = this.products.filter(x => x.id !== Number(id))
    this.storage.removeItem(id)
    this.productsIdQuantity = this.storage.getAllItems();
  }


  updateTotalPrice(productsIdQuantity) {
    this.total = 0.00;
    for (const map of productsIdQuantity) {
      for (const product of this.products) {
        if (Number(product.id) === Number(map[0])) {
          this.total += (Number(product.price) * Number(map[1]));
        }
      }
    }
  }

  onQuantityUpdate(quantity: number, id: string) {
    this.storage.saveProperty(id, quantity);
    this.quantity = quantity;
    this.productsIdQuantity = this.storage.getAllItems();
    this.updateTotalPrice(this.productsIdQuantity);
  }

  getItemCount(id) {
    return this.storage.getProperty(id);
  }

}
