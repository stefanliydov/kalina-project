import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Item } from 'src/app/models/Item';
import { StorageService } from 'src/app/services/storage/storage.service';
import { UserService } from 'src/app/services/user/user.service';
import {  faTrashAlt, faEdit } from '@fortawesome/free-solid-svg-icons'
import { ItemService } from 'src/app/services/item/item.service';


@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.scss']
})
export class ItemComponent implements OnInit {

  @Input()item: Item;
  isAdmin: boolean=false;
  isBusinessCustomer: boolean=false;
  trashIcon = faTrashAlt;
  editIcon = faEdit;
  @Output() delete: EventEmitter<any> = new EventEmitter();

  constructor(private storage: StorageService, private userService: UserService, private itemService: ItemService, private router: Router) { }

  ngOnInit(): void {
    this.isAdmin = this.userService.isAdmin();
    this.isBusinessCustomer = this.userService.isBusinessCustomer();
  }

  addToCart() {
    this.storage.addItem(this.item.id)
  }

  deleteHandler(id: number){
      this.itemService.deleteItem(id, this.item.category).subscribe(x => this.delete.emit());
      
  }

  editHandler(id: number){
  this.router.navigateByUrl(`/admin/edit/${id}`)    
}
}
