import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Item } from 'src/app/models/Item';
import { ItemService } from 'src/app/services/item/item.service';
import { StorageService } from 'src/app/services/storage/storage.service';

@Component({
  selector: 'app-edit-item',
  templateUrl: './edit-item.component.html',
  styleUrls: ['./edit-item.component.scss']
})
export class EditItemComponent implements OnInit {

  id: string;
  item: Item;
  addItemForm = this.fb.group({
    title: ['', Validators.required],
    price: ['', Validators.required],
    image: ['', Validators.required],
    category: ['', Validators.required],
    description: ['', Validators.required]
  });
  message:string;
  showMessage:boolean;
  criteriaControl = new FormControl('', Validators.required);
  readonly categories: string[] = ["woman", "men", "kids"] 
  constructor(private itemService: ItemService, private activatedRoute: ActivatedRoute, private router: Router, private fb: FormBuilder) { }
  selectedCategory: string;

  ngOnInit(): void {
    this.getItem();
  }

  getItem() {
    this.id = this.activatedRoute.snapshot.paramMap.get('id');
    this.itemService.getItemById(this.id).subscribe(
      (item) => {
        this.addItemForm.get("title").setValue(item.title);
        this.addItemForm.get("description").setValue(item.description);
        this.addItemForm.get("price").setValue(item.price);
        this.addItemForm.get("image").setValue(item.image);
        this.addItemForm.get("category").setValue(item.category);
        this.selectedCategory=item.category;
      },
      (error) => this.router.navigateByUrl("/home"));
  }

  onSubmit() {
    const item = this.createItem();
    this.itemService.editItem(item).subscribe(
      (success) => this.handleSuccess(),
      (error) => this.handleError());
  }

  private createItem(): Item {
    return {
      id: Number(this.id),
      title: this.addItemForm.get("title").value,
      description: this.addItemForm.get("description").value,
      price: this.addItemForm.get("price").value,
      image: this.addItemForm.get("image").value,
      category: this.addItemForm.get("category").value,
      reviews: []
    }
  }

  handleError(): void {
    this.showMessage = true;
    this.message = "ERROR! Item was not edited. Contact administrator.";
    setTimeout(() => {
      this.showMessage = false;
  }, 800);
  }

  handleSuccess() {
    this.showMessage = true;
    this.message = "Item edited succesfully!";
    setTimeout(() => {
      this.showMessage = false;
  }, 800);
  }
  select(category: string){
    this.addItemForm.get("category").setValue(category);
  }

}

