import { Component, Input, OnInit } from '@angular/core';
import { IReview } from 'src/app/models/Review';

@Component({
  selector: 'app-item-review',
  templateUrl: './item-review.component.html',
  styleUrls: ['./item-review.component.scss']
})
export class ItemReviewComponent implements OnInit {

  @Input() review: IReview;
  thumbnailColor: string;
  color: string;

  constructor() { }

  ngOnInit(): void {
    this.setRandomBackgroundThumbnailColor();
  }


  setRandomBackgroundThumbnailColor(){
    this.color = '#'+(Math.random()+999).toString(16).substr(-6);
    this.thumbnailColor = '#'+Math.random().toString(16).substr(-6);;
  }
}
