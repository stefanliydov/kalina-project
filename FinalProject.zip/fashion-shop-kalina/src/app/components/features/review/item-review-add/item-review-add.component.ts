import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { IAddReview } from 'src/app/models/Review';
import { FirstLetterPipe } from 'src/app/pipes/first-letter.pipe';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-item-review-add',
  templateUrl: './item-review-add.component.html',
  styleUrls: ['./item-review-add.component.scss']
})
export class ItemReviewAddComponent implements OnInit {

  @Input() id: string;
  username: string;
  review: IAddReview;
  titleEmpty: boolean;
  @Output() addReview = new EventEmitter<any>();

  addReviewForm = this.fb.group({
    title: [''],
    comment: [''],
    rating: ['']
  });
  
  constructor(private fb: FormBuilder,
    private userService: UserService,) { }

  ngOnInit(): void {
    this.username = this.userService.getLocalProperty('username');
    this.onChanges();
  }


  onSubmit() {
    this.review = this._setReview(this.addReviewForm.value);
    this.addReview.emit(this.review);
    this.addReviewForm.reset();
  }

  _setReview(data: any): IAddReview {
    var formRating: number = data.rating;
    if (data.rating == "") {
      formRating = 0;
    }
    return {
      userUsername: this.username,
      comment: data.comment,
      title: data.title,
      rating: formRating,
    }
  }

  onChanges() {
    this.addReviewForm.valueChanges.subscribe(val => {
      val.title == "" ? this.titleEmpty = false : this.titleEmpty = true;
    })
  }
}
