import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemReviewAddComponent } from './item-review-add.component';

describe('ItemReviewAddComponent', () => {
  let component: ItemReviewAddComponent;
  let fixture: ComponentFixture<ItemReviewAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ItemReviewAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemReviewAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
