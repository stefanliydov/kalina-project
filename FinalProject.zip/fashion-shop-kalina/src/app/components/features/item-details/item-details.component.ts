import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Item } from 'src/app/models/Item';
import { IAddReview, IReview } from 'src/app/models/Review';
import { ItemService } from 'src/app/services/item/item.service';
import { StorageService } from 'src/app/services/storage/storage.service';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.scss']
})
export class ItemDetailsComponent implements OnInit {

  item: Item;
  reviews$: Observable<IReview[]>;
  products: Item[]
  id: string;
  addReviewShow: boolean;
  addReviewButtonPositiveText: string = 'Open Review Box';
  addReviewButtonNegativeText: string = 'Close Review Box';
  addReviewButtonText: string;
  showMessage: boolean = false;

  constructor(private storage: StorageService, private itemService: ItemService, private activatedRoute: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
   this.getItem();
   this.getReviews();
   this.addReviewButtonText = this.addReviewButtonPositiveText;

  }
  getReviews() {
    const id = Number(this.activatedRoute.snapshot.paramMap.get('id'));
    this.reviews$ = this.itemService.getItemReviews(id);
  }

  addToCart() {
    this.storage.addItem(this.id);
    this.toggleMessage();
  }

  toggleMessage() {
    this.showMessage = true;
    setTimeout(() => {
      this.showMessage = false;
  }, 800);
  }

  addReview(review: IAddReview, id: number) {
    this.itemService.addItemReview(review, id).subscribe(r => {
      this.getItem();
      this.getReviews();
    });

  }

  toggleAddReview() {
    this.addReviewShow = !this.addReviewShow;
    this.addReviewShow ? this.addReviewButtonText = this.addReviewButtonNegativeText : this.addReviewButtonText = this.addReviewButtonPositiveText;
  }


  private getItem() {
    this.id = this.activatedRoute.snapshot.paramMap.get('id');
    this.itemService.getItemById(this.id).subscribe(
      (item) => this.item = item,
      (error) => this.router.navigateByUrl("/home"));
  }
}

