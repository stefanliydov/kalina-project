import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Item } from 'src/app/models/Item';
import { ItemService } from 'src/app/services/item/item.service';

@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.scss']
})
export class ItemListComponent implements OnInit, OnDestroy {

  category: string;
  products: Item[];
  filteredProducts: Item[]
  readonly criterias = ["Price asc", "Name asc", "Price desc", "Name desc"]
  criteriaControl = new FormControl('');
  productsFilter: string = '';

  constructor(private activatedRoute: ActivatedRoute,
    private itemService: ItemService) { }
  ngOnDestroy(): void {
    const mainContainer = <HTMLElement>document.getElementsByClassName("header-container")[0]
    mainContainer.style["height"] = "44rem"
  }

  ngOnInit(): void {
    this.products = [];
    this.getProductSByCategory();
    const mainContainer = <HTMLElement>document.getElementsByClassName("header-container")[0]
    mainContainer.style["height"] = "20rem"
  }

  getProductSByCategory() {
    this.activatedRoute.params.subscribe(x => {
      this.category = x['category']
      this.itemService.getItemByCategory(this.category).subscribe(
        (items) => { this.products = [...items]
        this.filteredProducts = this.products;}
      )
    });
  }

  select(criteria){
    switch(criteria){
    case this.criterias[0]: {
        this.sortByPriceAsc();
      break;
    }
    case this.criterias[1]: {
      this.sortByNameAsc()
      break;
    }
    case this.criterias[2]: {
      this.sortByPriceDesc();

      break;
    }
    case this.criterias[3]: {
      this.sortByNameDesc()

      break;
    }
  }

          
  }
  sortByNameDesc() {
    this.filteredProducts = this.filteredProducts.sort((a,b) => this.stringSort(b.title, a.title))
  }
  sortByPriceDesc() {
    this.filteredProducts = this.filteredProducts.sort((a,b) => (b.price - a.price))
  }
  sortByNameAsc() {
    this.filteredProducts = this.filteredProducts.sort((a,b) => this.stringSort(a.title, b.title))
  }
  sortByPriceAsc() {
    this.filteredProducts = this.filteredProducts.sort((a,b) => (a.price - b.price))
  }

  stringSort(aTitle, bTitle): number{
    if(aTitle > bTitle){
      return 1;
    } else if(aTitle<bTitle){
    return -1
    }
      return 0;
  }

  performSearch() {
    this.filteredProducts = this.products.filter(result => this.filterResultList(result));
  }

  private filterResultList(result: Item): boolean {
    return result.title && 
      result.title.indexOf(this.productsFilter) !== -1 
  }

  itemDeleted(){
    this.getProductSByCategory();
  }
}
