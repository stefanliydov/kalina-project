import { IReview } from "./Review";

export interface Item {
    id: number,
    title: string,
    description: string,
    price: number,
    image: string,
    category: string,
    reviews: IReview[]
}
