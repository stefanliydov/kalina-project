import { IReview } from "./Review";


export interface ItemModel {
    id: number,
    title: string,
    description: string,
    price: number,
    image: string,
    category: string,
    createDate16114107: Date;
    modifyDate16114107: Date ;
    reviews: IReview[]
}