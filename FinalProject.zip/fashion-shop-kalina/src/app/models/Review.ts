export interface IReview {
    id: number,
    title: string,
    comment: string,
    rating: number,
    userUsername: string,
}
export interface IAddReview {
    title: string,
    comment: string,
    rating: number,
    userUsername: string,
}