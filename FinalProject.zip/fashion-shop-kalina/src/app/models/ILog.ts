export interface ILog{
     tableName: string,
     operationType: string;
     createDate16114107: Date;
}