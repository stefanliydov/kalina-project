import { BearerInterceptor } from './components/interceptors/bearer.interceptor';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './core/header/header.component';
import { LoginComponent } from './components/login/login.component';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { ButtonModule } from 'primeng/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HomeComponent } from './components/home/home.component';
import { RegisterComponent } from './components/register/register.component';
import { ItemListComponent } from './components/features/item-list/item-list.component';
import { ItemComponent } from './components/features/item/item.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BasketComponent } from './components/basket/basket.component';
import { ItemDetailsComponent } from './components/features/item-details/item-details.component';
import { StarRatingComponent } from './components/shared/star-rating/star-rating.component';
import { FooterComponent } from './core/footer/footer.component';
import { ToastModule } from 'primeng/toast';
import { AddItemComponent } from './components/features/add-item/add-item.component';
import { ItemReviewComponent } from './components/features/review/item-review/item-review.component';
import { ItemReviewAddComponent } from './components/features/review/item-review-add/item-review-add.component';
import { FirstLetterPipe } from './pipes/first-letter.pipe';
import { AdminPanelComponent } from './core/admin-panel/admin-panel.component';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { EditItemComponent } from './components/features/edit-item/edit-item.component';
import { DataTableComponent } from './core/admin-panel/data/data-table/data-table.component';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    HomeComponent,
    RegisterComponent,
    ItemListComponent,
    ItemComponent,
    BasketComponent,
    ItemDetailsComponent,
    StarRatingComponent,
    FooterComponent,
    AddItemComponent,
    ItemReviewComponent,
    ItemReviewAddComponent,
    FirstLetterPipe,
    AdminPanelComponent,
    EditItemComponent,
    DataTableComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    InputTextModule,
    PasswordModule,
    ButtonModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    FontAwesomeModule,
    ToastModule,
    BrowserAnimationsModule,
    MatSelectModule,
    MatInputModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule

  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: BearerInterceptor,
    multi: true
}],
  bootstrap: [AppComponent],

})
export class AppModule { }
