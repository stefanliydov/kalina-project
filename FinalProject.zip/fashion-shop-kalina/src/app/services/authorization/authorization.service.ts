import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { APIUrl, AuthKeywords, InterceptorSkipHeader } from 'src/app/constants/constants';
import { IUserLogin } from 'src/app/models/IUserLogin';
import { IUserRegister } from 'src/app/models/IUserRegister';
import { CookieWrapperService } from '../cookies/cookie-wrapper.service';
import { StorageService } from '../storage/storage.service';

@Injectable({
  providedIn: 'root'
})
export class AuthorizationService {


  constructor(private http: HttpClient,
    private cookieService: CookieWrapperService,
    private storageService: StorageService) { }

  login(user: IUserLogin) {
    return this.http.post(`${APIUrl.BACK_END_URL}/login`, user);
  }

  register(user: IUserRegister) {
    return this.http.post(`${APIUrl.BACK_END_URL}/register`, user);
  }

  refresh(refresh: string) {
    const headers = new HttpHeaders().set(InterceptorSkipHeader, '');
    return this.http.post(`${APIUrl.BACK_END_URL}/token/refresh`, { refresh: refresh }, { headers: headers });
  }

  logout(): void {
    this.cookieService.deleteToken(AuthKeywords.AUTH_TOKEN);
    this.storageService.empty();
  }
}
