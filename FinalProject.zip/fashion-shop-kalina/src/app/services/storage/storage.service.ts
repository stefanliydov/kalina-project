import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StorageService {

  constructor() { }

  saveProperty(key: string, value: any) {
    localStorage.setItem(key, value);
  }

  getProperty(key: string): string {
    return localStorage.getItem(key);
  }


  getAllItems() {
    const values = new Map()
    Object.keys(localStorage).forEach(x => values.set(x, localStorage.getItem(x)))
    return values;
  }

  addItem(id) {
    const item = localStorage.getItem(id)
    if (!item) {
      localStorage.setItem(id, "1");
      return;
    }
    localStorage.setItem(id, (parseInt(item, 10) + 1).toString());
  }

  removeItem(key: string) {
    localStorage.removeItem(key);
  }

  getItemSize() {
    let size = 0;
    Object.keys(localStorage).slice(2).forEach(x => size += Number(localStorage.getItem(x)));
    return size;
  }

  empty() {
    localStorage.clear()
  }
}
