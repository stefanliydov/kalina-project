import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { APIUrl } from 'src/app/constants/constants';
import { ILog } from 'src/app/models/ILog';

@Injectable({
  providedIn: 'root'
})
export class LogService {

  constructor(private http: HttpClient) { }

  getItemList(): Observable<ILog[]> {
    return this.http.get<ILog[]>(`${APIUrl.BACK_END_URL}/log`);
  }
}
