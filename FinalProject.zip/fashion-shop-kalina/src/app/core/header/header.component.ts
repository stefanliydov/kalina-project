import { Component, OnInit } from '@angular/core';
import { ResolveEnd, Router } from '@angular/router';
import { AuthKeywords } from 'src/app/constants/constants';
import { AuthorizationService } from 'src/app/services/authorization/authorization.service';
import { CookieWrapperService } from 'src/app/services/cookies/cookie-wrapper.service';
import { StorageService } from 'src/app/services/storage/storage.service';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  router: string;

  constructor(private _router: Router,
    private cookieService: CookieWrapperService,
    private authService: AuthorizationService,
    private userService: UserService,
    private storageService: StorageService) {
    //REFERENCE: https://stackoverflow.com/questions/45320416/angular-router-url-returns-slash
    // this._router.events.subscribe((routerData) => {
    //   if (routerData instanceof ResolveEnd) {
    //     this.router = routerData.url;
    //   }
    // })
  }

  ngOnInit(): void {

  }

  goToBottom() {
    window.scrollTo(0, document.body.scrollHeight);
  }

  isAuthanticated() {
    return this.cookieService.tokenExist(AuthKeywords.AUTH_TOKEN);
  }

  logout() {
    this.authService.logout();
  }

  isAdmin() {
    return this.userService.isAdmin();
  }

  isBusinessCustomer(){
    return this.userService.isBusinessCustomer();

  }

  getItemCount() {
    return this.storageService.getItemSize()
  }
}
