import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Item } from 'src/app/models/Item';
import { ItemModel } from 'src/app/models/ItemModel';
import { ItemService } from 'src/app/services/item/item.service';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-admin-panel',
  templateUrl: './admin-panel.component.html',
  styleUrls: ['./admin-panel.component.scss']
})
export class AdminPanelComponent implements OnInit {

  constructor(private userService: UserService, private sanitizer: DomSanitizer, private itemService: ItemService) { }
  downloadJsonHref: any
  resJsonResponse: ItemModel[];
  ngOnInit(): void {
    this.itemService.getItemList().subscribe(items => {
      this.resJsonResponse = items;
      this.generateDownloadJsonUri()})
  }

  isAdmin(){
    return this.userService.isAdmin();
  }

  generateDownloadJsonUri() {
    var theJSON = JSON.stringify(this.resJsonResponse);
    var uri = this.sanitizer.bypassSecurityTrustUrl("data:text/json;charset=UTF-8," + encodeURIComponent(theJSON));
    this.downloadJsonHref = uri;
}
}
