import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { DomSanitizer } from '@angular/platform-browser';
import { ILog } from 'src/app/models/ILog';
import { LogService } from 'src/app/services/log/log.service';

@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss']
})
export class DataTableComponent implements OnInit {
  displayedColumns: string[] = ['tableName', 'operationType', 'createDate16114107'];
  dataSource: MatTableDataSource<ILog>;
  logData: ILog[];
  logFiltered: ILog[];
  searchWord: string;
  downloadJsonHref: any;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private logService: LogService, private sanitizer: DomSanitizer) { }

  ngOnInit(): void {
    this.fetchLogData();
  }

  fetchLogData() {
    this.logService.getItemList().subscribe(logData => {
      this.logData = logData;
      console.log(this.logData)
      this.dataSource = new MatTableDataSource(this.logData);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
      this.generateDownloadJsonUri();
    })
  }

  generateDownloadJsonUri() {
    var theJSON = JSON.stringify(this.logData);
    var uri = this.sanitizer.bypassSecurityTrustUrl("data:text/json;charset=UTF-8," + encodeURIComponent(theJSON));
    this.downloadJsonHref = uri;
  }
  performSearch() {
    this.logFiltered = this.logData.filter(result => this.filterResultList(result));
    this.dataSource = new MatTableDataSource(this.logFiltered);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  private filterResultList(result: ILog): boolean {
    return result.tableName &&
      result.tableName.indexOf(this.searchWord) !== -1 ||
      result.operationType &&
      result.operationType.indexOf(this.searchWord) !== -1
  }

}


