import { BasketComponent } from './components/basket/basket.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ItemDetailsComponent } from './components/features/item-details/item-details.component';
import { ItemListComponent } from './components/features/item-list/item-list.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { AddItemComponent } from './components/features/add-item/add-item.component';
import { IsAdminGuard } from './components/guards/is-admin.guard';
import { AdminPanelComponent } from './core/admin-panel/admin-panel.component';
import { NotLoggedGuard } from './components/guards/not-logged.guard';
import { IsBussinessCustomerGuard } from './components/guards/is-bussiness-customer.guard';
import { LoggedGuard } from './components/guards/logged.guard';
import { EditItemComponent } from './components/features/edit-item/edit-item.component';
import { DataTableComponent } from './core/admin-panel/data/data-table/data-table.component';


const routes: Routes = [
  { path: 'home', component: HomeComponent, canActivate:[LoggedGuard] },
  { path: 'login', component: LoginComponent, canActivate: [NotLoggedGuard]},
  { path: 'register', component: RegisterComponent, canActivate: [NotLoggedGuard]},
  { path: 'item-list/:category', component: ItemListComponent, canActivate:[LoggedGuard]},
  { path: 'basket', component: BasketComponent, canActivate:[LoggedGuard] },
  { path: 'admin/add-item', component: AddItemComponent, canActivate: [IsBussinessCustomerGuard] },
  { path: 'admin/edit/:id', component: EditItemComponent, canActivate: [IsBussinessCustomerGuard] },
  { path: 'admin/data-table', component: DataTableComponent, canActivate: [IsAdminGuard] },
  { path: 'admin', component: AdminPanelComponent, canActivate: [IsBussinessCustomerGuard] },
  { path: 'item-list/:category/item/:id', component: ItemDetailsComponent },
  { path: '**', redirectTo: '/home', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
