package com.company.constants;

public class Success {
    public static final String USER_CREATED = "User created successfully!";
}
