package com.company.errors.exceptions;

public class UserNotFoundException extends RuntimeException {
}
