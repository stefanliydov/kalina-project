package com.company.errors.exceptions;

public class DnaTestNotFoundException extends RuntimeException {

    public DnaTestNotFoundException(String message) {
        super(message);
    }
}
