package com.company.controllers;

import com.company.data.entities.Item;
import com.company.services.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "item")
public class ItemController {

    @Autowired
    private ItemService itemService;

    @RequestMapping(method = RequestMethod.GET, path = "/all-items")
    public ResponseEntity<List<Item>> getItemList() {
        return new ResponseEntity<>(itemService.getAllItems(), HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET, path = "/{id}")
    public ResponseEntity<Item> getItemById(@PathVariable final Long id) {
        return new ResponseEntity<>(this.itemService.getItemById(id), HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET, path = "/category/{category}")
    public ResponseEntity<List<Item>> getItemsByCategory(@PathVariable final String category) {
        return new ResponseEntity<>(itemService.getItemsByCategory(category), HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<Item> addItem(@RequestBody final Item item) {
        return new ResponseEntity<>(itemService.createItem(item), HttpStatus.CREATED);
    }


}
