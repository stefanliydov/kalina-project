package com.company.services;

import com.company.data.entities.Item;
import com.company.repositories.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ItemService {

    @Autowired
    private ItemRepository itemRepository;

    public List<Item> getAllItems() {
        return this.itemRepository.findAll();
    }

    public Item getItemById(Long id) {
        return this.itemRepository.findById(id).orElseThrow(() -> new RuntimeException("Item not found"));
    }

    public List<Item> getItemsByCategory(String category) {
        return this.itemRepository.findAllByCategory(category);
    }

    public Item createItem(Item item) {
        this.itemRepository.save(item);
        return item;
    }
}
