export interface IUserRegister {
    username: string,
    email: string,
    password: string
}
