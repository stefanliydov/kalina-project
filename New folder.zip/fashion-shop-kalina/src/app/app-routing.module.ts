import { BasketComponent } from './components/basket/basket.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ItemDetailsComponent } from './components/features/item-details/item-details.component';
import { ItemListComponent } from './components/features/item-list/item-list.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { AddItemComponent } from './components/features/add-item/add-item.component';
import { IsAdminGuard } from './components/guards/is-admin.guard';


const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'item-list/:category', component: ItemListComponent },
  { path: 'basket', component: BasketComponent },
  { path: 'add-item', component: AddItemComponent, canActivate: [IsAdminGuard] },
  { path: 'item-list/:category/item/:id', component: ItemDetailsComponent },
  { path: '**', redirectTo: '/login', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
