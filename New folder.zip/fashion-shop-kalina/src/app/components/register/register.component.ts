import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { take } from 'rxjs/operators';
import { IUserRegister } from 'src/app/models/IUserRegister';
import { AuthorizationService } from 'src/app/services/authorization/authorization.service';
import { MessageService } from 'primeng/api';
import { ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
  providers: [MessageService],
  encapsulation: ViewEncapsulation.None
})
export class RegisterComponent implements OnInit {


  registerForm = this.fb.group({
    username: ['', Validators.required],
    password: ['', [Validators.required]],
    email: ['', [Validators.required, Validators.email]]
  });

  constructor(private fb: FormBuilder, private authService: AuthorizationService, private messageService: MessageService, private router: Router) { }

  ngOnInit(): void {
  }

  showSuccess() {
    this.messageService.add({ severity: 'success', summary: 'Success', detail: 'User has been successfully registered' });
  }

  showError() {
    this.messageService.add({ severity: 'error', summary: 'Error', detail: 'User was not registered, try again!' });
  }

  clear() {
    this.messageService.clear();
  }

  onSubmit() {
    const user: IUserRegister = this.extractUserFromForm();
    this.authService.register(user).subscribe(
      success => {
        this.router.navigate(['/login']);
        this.showSuccess();
      },
      error => this.showError())
  }

  private extractUserFromForm(): IUserRegister {
    return {
      username: this.registerForm.get("username").value,
      email: this.registerForm.get("email").value,
      password: this.registerForm.get("password").value
    }
  }

  private handleErrors(err: HttpErrorResponse) {
    if (err.status == 400) {
      alert(err.error.error);
    }
  }
}
