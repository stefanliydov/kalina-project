import { Component, OnInit, Input, ViewChildren, QueryList, ComponentFactoryResolver, ViewChild, ViewContainerRef } from '@angular/core';
import { faStar as faStarFull, faStarHalfAlt, IconDefinition } from '@fortawesome/free-solid-svg-icons'
import { faStar } from '@fortawesome/free-regular-svg-icons'
import { FaIconComponent } from '@fortawesome/angular-fontawesome';

@Component({
  selector: 'app-star-rating',
  templateUrl: './star-rating.component.html',
  styleUrls: ['./star-rating.component.scss']
})
export class StarRatingComponent implements OnInit {
  @Input() rating;
  @ViewChildren('star') stars: QueryList<FaIconComponent>;
  @ViewChild('vcRef', { read: ViewContainerRef, static: true })
  private vcRef: ViewContainerRef;

  faStarFull = faStarFull;
  faStar = faStar;
  faStarHalfAlt = faStarHalfAlt;


  constructor(private cfr: ComponentFactoryResolver,
  ) { }

  ngOnInit() {
    this._generateStars();
  }

  _generateStars(): void {
    const rounded = Math.floor(this.rating);

    for (let i = 0; i < rounded; i++) {
      this._createStarElement(faStarFull);
    }

    if (this.rating - rounded !== 0) {
      this._createStarElement(faStarHalfAlt);
    }

    const empty = 5 - Math.ceil(this.rating);

    for (let i = 0; i < empty; i++) {
      this._createStarElement(faStar);
    }

  }

  _createStarElement(icon: IconDefinition): void {
    const factory = this.cfr.resolveComponentFactory(FaIconComponent);
    const faIcon = this.vcRef.createComponent(factory);
    faIcon.instance.styles = { 'color': 'black' };
    faIcon.instance.styles = { 'font-size': '1.3rem' };
    faIcon.instance.icon = icon;
    faIcon.instance.ngOnChanges({});
  }

}
