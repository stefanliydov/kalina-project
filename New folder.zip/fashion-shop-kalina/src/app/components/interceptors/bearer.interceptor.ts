import { AuthorizationService } from 'src/app/services/authorization/authorization.service';
import { AuthKeywords, InterceptorSkipHeader } from './../../constants/constants';
import { CookieWrapperService } from './../../services/cookies/cookie-wrapper.service';
import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { take } from 'rxjs/operators';

@Injectable()
export class BearerInterceptor implements HttpInterceptor {



  constructor(private cookieService: CookieWrapperService,
    private authService: AuthorizationService) { }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    const token = this.cookieService.getToken(AuthKeywords.AUTH_TOKEN);
    let headers = token
      ? {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      }
      : {};

    request = request.clone({
      url: `${request.url}`,
      setHeaders: headers,
    })
    return next.handle(request);
  }
}
