import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { take } from 'rxjs/operators';
import { AuthKeywords } from 'src/app/constants/constants';
import { Item } from 'src/app/models/Item';
import { IUserLogin } from 'src/app/models/IUserLogin';
import { AuthorizationService } from 'src/app/services/authorization/authorization.service';
import { CookieWrapperService } from 'src/app/services/cookies/cookie-wrapper.service';
import { ItemService } from 'src/app/services/item/item.service';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.scss']
})
export class AddItemComponent implements OnInit {

  addItemForm = this.fb.group({
    title: ['', Validators.required],
    price: ['', Validators.required],
    image: ['', Validators.required],
    category: ['', Validators.required],
    description: ['', Validators.required]
  });

  constructor(private fb: FormBuilder,
    private itemService: ItemService,
    private router: Router) { }

  ngOnInit(): void {
  }

  onSubmit() {
    console.log("H")
    const item = this.createItem();
    this.itemService.addItem(item).subscribe(x => console.log(x));
    // this.router.navigate(["home"]);
  }

  private createItem(): Item {
    return {
      id: undefined,
      title: this.addItemForm.get("title").value,
      description: this.addItemForm.get("description").value,
      price: this.addItemForm.get("price").value,
      image: this.addItemForm.get("image").value,
      category: this.addItemForm.get("category").value
    }
  }
}
