import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';

import { ItemListComponent } from './item-list.component';

describe('ItemListComponent', () => {
  let component: ItemListComponent;
  let products;
  let mockActivatedRoute;
  let mockItemService;


  beforeEach(() => {
    products = [{
      id: '1',
      title: 'Title',
      description: 'description',
      price: 100.99,
      image: '',
      category: 'MEN'
    },
    {
      id: '1',
      title: 'Title',
      description: 'description',
      price: 100.99,
      image: '',
      category: 'WOMEN'
    },
    {
      id: '1',
      title: 'Title',
      description: 'description',
      price: 100.99,
      image: '',
      category: 'KIDS'
    }];

    mockActivatedRoute = jasmine.createSpyObj([]);
    mockItemService = jasmine.createSpyObj(['getItemByCategory']);

    component = new ItemListComponent(mockActivatedRoute, mockItemService);
  })

  describe('getProductSByCategory', () => {

    it('should return product objects from a particular category', () => {
      mockItemService.getItemByCategory.and.returnValue(of(true));

      component.products = products;

      component.getProductSByCategory();

      expect(component.products.length).toBe(0);
    })
  })
});
