import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Item } from 'src/app/models/Item';
import { ItemService } from 'src/app/services/item/item.service';

@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.scss']
})
export class ItemListComponent implements OnInit, OnDestroy {

  category: string;
  products: Item[];

  constructor(private activatedRoute: ActivatedRoute,
    private itemService: ItemService) { }
  ngOnDestroy(): void {
    const mainContainer = <HTMLElement>document.getElementsByClassName("header-container")[0]
    mainContainer.style["height"] = "44rem"
  }

  ngOnInit(): void {
    this.products = [];
    this.getProductSByCategory();
    const mainContainer = <HTMLElement>document.getElementsByClassName("header-container")[0]
    mainContainer.style["height"] = "20rem"
    console.log(this.products);
  }

  getProductSByCategory() {
    this.activatedRoute.params.subscribe(x => {
      this.category = x['category']
      this.itemService.getItemByCategory(this.category).subscribe(
        (items) => { this.products = [...items]
        console.log(this.products) }
      );
    });
  }
}
