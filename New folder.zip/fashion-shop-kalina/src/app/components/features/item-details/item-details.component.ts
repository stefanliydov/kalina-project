import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Item } from 'src/app/models/Item';
import { ItemService } from 'src/app/services/item/item.service';
import { StorageService } from 'src/app/services/storage/storage.service';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.scss']
})
export class ItemDetailsComponent implements OnInit {

  item: Item;
  products: Item[]
  id: string;

  constructor(private storage: StorageService, private itemService: ItemService, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.paramMap.get('id');
    this.itemService.getItemById(this.id).subscribe(
      item => this.item = item);
  }

  addToCart() {
    this.storage.addItem(this.id)
  }
}

