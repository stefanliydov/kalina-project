import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { Item } from 'src/app/models/Item';
import { StorageService } from 'src/app/services/storage/storage.service';

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.scss']
})
export class ItemComponent implements OnInit {

  @Input()item: Item;

  constructor(private storage: StorageService) { }

  ngOnInit(): void {

  }

  addToCart() {
    this.storage.addItem(this.item.id)
  }
}
