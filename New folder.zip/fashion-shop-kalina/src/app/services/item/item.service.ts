import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { APIUrl } from 'src/app/constants/constants';
import { Item } from 'src/app/models/Item';

@Injectable({
  providedIn: 'root'
})
export class ItemService {

  constructor(private http: HttpClient) { }

  getItemList(): Observable<Item[]> {
    return this.http.get<Item[]>(`${APIUrl.BACK_END_URL}/item/all-items`);
  }

  getItemById(id: string): Observable<Item> {
    return this.http.get<Item>(`${APIUrl.BACK_END_URL}/item/${id}`);
  }

  getItemByCategory(category: string): Observable<Item[]> {
    return this.http.get<Item[]>(`${APIUrl.BACK_END_URL}/item/category/${category}`);
  }

  addItem(item: Item): Observable<Item> {
    return this.http.post<Item>(`${APIUrl.BACK_END_URL}/item`, item);
  }
}
