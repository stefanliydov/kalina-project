import { Injectable } from '@angular/core';
import { AuthKeywords, Roles } from 'src/app/constants/constants';
import { CookieWrapperService } from '../cookies/cookie-wrapper.service';
import { StorageService } from '../storage/storage.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(
    private storageService: StorageService,
    private cookieService: CookieWrapperService
  ) { }

  setLocalProperty(key: string, value: any): void {
    this.storageService.saveProperty(key, value);
  }

  getLocalProperty(key: string): string {
    return this.storageService.getProperty(key);
  }

  isLogged(): boolean {
    return this.cookieService.tokenExist(AuthKeywords.AUTH_TOKEN)
  }

  isAdmin(): boolean {
    if (this.cookieService.tokenExist(AuthKeywords.AUTH_TOKEN) && this.getLocalProperty(AuthKeywords.ROLES)) {
      return this.getLocalProperty(AuthKeywords.ROLES).indexOf(Roles.ADMIN) !== -1;
    }
    return false;
  }
}
